const API = "http://localhost:5000/api/quote";

async function getQuote() {
  const res = await fetch(API);
  const data = await res.json();
  document.getElementById("quote").innerText = data.quote;
}