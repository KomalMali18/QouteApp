const express = require("express");
const router = express.Router();

const quotes = [
  "Stay disciplined.",
  "Consistency creates success.",
  "Focus on progress, not perfection.",
  "Hard work beats talent.",
  "Keep going no matter what."
];

router.get("/quote", (req, res) => {
  const random = quotes[Math.floor(Math.random() * quotes.length)];
  res.json({ quote: random });
});

module.exports = router;